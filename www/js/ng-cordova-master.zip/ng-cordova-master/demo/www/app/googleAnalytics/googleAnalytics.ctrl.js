angular.module('demo.googleAnalytics.ctrl', [])

  .controller('GoogleAnalyticsCtrl', function ($scope, $log, $cordovaPreferences) {

  });
